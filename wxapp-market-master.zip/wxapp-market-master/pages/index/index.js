Page({
    data: {
        list: [
            {
                id: 'wheel',
                sub: 'wheel',
                name: '大转盘'
            },
            {
                id: 'scratch',
                sub: 'scratch',
                name: '刮刮乐'
            },
            {
                id: 'slotMachine',
                sub: 'slotMachine',
                name: '老虎机'
            },
            {
                id: 'fruitMachine',
                sub: 'fruitMachine',
                name: '水果机'
            },
            {
                id: 'gridcard',
                sub: 'gridcard',
                name: '九宫格翻纸牌'
            },
            {
                id: 'shake',
                sub: 'shake',
                name: '摇一摇'
            },
            {
                id: 'gestureLock',
                sub: 'gestureLock',
                name: '手势解锁'
            }
        ]
    }
})
